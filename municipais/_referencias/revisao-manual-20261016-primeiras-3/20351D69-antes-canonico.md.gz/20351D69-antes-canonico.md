---
titulo: "DECRETO Nº 757/2026"
uf: "RJ"
municipio: "ENGENHEIRO PAULO DE FRONTIN"
tipo: "Decreto"
numero: "757"
data: 
ano: "2026"
revogada: false
versao_texto: "publicação original"
publicacao: "Diário Oficial de 08/01/2026"
data_publicacao: 2026-01-08
codigo_identificador: "20351D69"
fonte: "https://www-storage.voxtecnologia.com.br/?m=sigpub.publicacao&f=265&i=publicado_119311_2026-01-08_6c57aafa86497f18b745b0981a5fa4fa.pdf"
baixado_em: 2026-10-15
---
# DECRETO Nº 757/2026

DECRETO Nº 757/2026
DECLARA EMERGÊNCIA ADMINISTRATIVA NO
ÂMBITO DO MUNICÍPIO DE ENGENHEIRO
PAULO
DE
FRONTIN/RJ,
ESTABELECE
MEDIDAS DE PREVENÇÃO, PREPARAÇÃO E
RESPOSTA PARA O PERÍODO DE CHUVAS
INTENSAS E DÁ OUTRAS PROVIDÊNCIAS.
O PREFEITO DO MUNICÍPIO DE ENGENHEIRO PAULO DE
FRONTIN, Estado do Rio de Janeiro, no uso de suas atribuições
legais,
CONSIDERANDO a proximidade do período historicamente
marcado por chuvas intensas na região, com recorrência de episódios
de alagamentos, enxurradas e deslizamentos, capazes de
comprometer a segurança da população, a continuidade dos serviços
públicos essenciais e a integridade de bens públicos e privados;
CONSIDERANDO o histórico municipal e regional de ocorrência
de eventos adversos associados a precipitações, com impactos
relevantes sobre áreas de encosta e locais suscetíveis a movimentos
de massa e instabilidades geotécnicas;
CONSIDERANDO a decisão proferida nos autos do Processo nº
0001070-25.2016.8.19.0022 (Ação Civil Pública), que determinou a
intimação do Departamento de Recursos Minerais - DRM-RJ para
realização de perícia técnica com análise geotécnica do terreno de
todo o Município, com atualização de pareceres e mapeamentos já
elaborados em 2012, 2017 e 2019, com participação conjunta das
Secretarias Municipais de Meio Ambiente e Defesa Civil e
levantamento de dados técnicos;
CONSIDERANDO que a mesma decisão judicial determinou que a
Procuradoria-Geral do Município comprove, em prazo fixado, o
estágio de tratativas e medidas preventivas e de minimização de
desastres, bem como a atuação integrada de secretarias e grupos de
trabalho voltados à resposta a desastres;
CONSIDERANDO a necessidade de adoção imediata de
providências administrativas e operacionais para assegurar a pronta
resposta, a mitigação de riscos, o planejamento preventivo e a
continuidade dos serviços públicos, inclusive para atendimento às
determinações judiciais, sob pena de responsabilizações e sanções
processuais;
CONSIDERANDO a necessidade de mobilização coordenada dos
órgãos municipais para ações preventivas e de resposta, com
mobilização de órgãos sob coordenação da Defesa Civil;

Art. 2º. A Emergência Administrativa tem por finalidade acelerar e
integrar medidas administrativas, técnicas e operacionais de:
I – prevenção e mitigação de riscos;
II – preparação e prontidão da Administração Pública;
III – resposta coordenada a ocorrências relacionadas a chuvas
intensas;
IV – recuperação emergencial de danos e restabelecimento de
serviços essenciais, quando necessário;
V – atendimento e consolidação de informações para cumprimento
das determinações judiciais no Processo nº 000107025.2016.8.19.0022.
Art. 3º. Fica autorizada a mobilização de todos os órgãos e entidades
da Administração Municipal, para atuação integrada, sob
coordenação da Defesa Civil Municipal, com apoio das Secretarias
Municipais de Meio Ambiente, Obras e Serviços, Assistência Social,
Saúde, Educação, Governo e demais unidades que se fizerem
necessárias, observadas as respectivas competências.
Art. 4º. Fica instituído o Comitê Municipal de Gestão de Riscos e
Resposta a Chuvas Intensas, com a finalidade de planejar, coordenar
e monitorar ações decorrentes deste Decreto.
§1º O Comitê será composto, no mínimo, por representantes (titulares
e suplentes) de:
I – Defesa Civil (coordenação);
II – Secretaria Municipal de Meio Ambiente;
III – Secretaria Municipal de Obras e Serviços;
IV – Secretaria Municipal de Assistência Social;
V – Secretaria Municipal de Saúde;
VI – Secretaria Municipal de Governo;
VII – Procuradoria-Geral do Município;
VIII – Secretaria Municipal de Planejamento;
IX – Secretaria de Fazenda.
§2º O Comitê poderá requisitar apoio técnico de órgãos estaduais e
federais, inclusive do DRM-RJ, bem como convidar entidades,
concessionárias e especialistas, conforme necessidade.
Art. 5º. A Procuradoria-Geral do Município, com apoio das
Secretarias competentes, deverá consolidar e organizar as
informações necessárias para atendimento às determinações judiciais,
incluindo, quando aplicável, dados sobre:
I – famílias realocadas e ações correlatas;
II – cadastro e acompanhamento social;
III – medidas adotadas em áreas de risco;
IV – ações preventivas e de minimização;
V – atuação integrada das Secretarias e grupos de trabalho
Art. 6º. Para assegurar a continuidade dos serviços e a pronta
resposta às situações emergenciais relacionadas ao objeto deste
Decreto, ficam autorizadas as medidas administrativas necessárias à
celeridade de contratações, observada a legislação aplicável,
inclusive a dispensa de licitação nas hipóteses legais de emergência,
quando caracterizada a urgência, com justificativa técnica e limitação
temporal do objeto, caso necessárias.
Parágrafo único. Em especial, poderão ser adotadas as providências
previstas no art. 75, VIII, da Lei nº 14.133/2021, nos limites e
condições legais, para aquisições, serviços e parcelas de obras
necessárias ao atendimento de situação emergencial.

DECRETA:
Art. 1º. Fica declarada EMERGÊNCIA ADMINISTRATIVA no
âmbito do Município de Engenheiro Paulo de Frontin/RJ, em razão
da iminência do período de chuvas intensas e do histórico de
catástrofes associadas, com potencial comprometimento da segurança

Art. 7º. Fica autorizada, durante a vigência deste Decreto, a adoção
de medidas de reforço operacional quando necessárias, tais como:
I – remanejamento temporário de servidores e equipes;
II – ampliação de regime de plantão e sobreaviso;

www.diariomunicipal.com.br/aemerj

1

Rio de Janeiro , 08 de Janeiro de 2026 • Diário Oficial dos Municípios do Estado do Rio de Janeiro • ANO XVII | Nº 4036a - Edição
Extraordinária
III – priorização de atendimento a ocorrências e demandas
relacionadas a risco geológico, drenagem, desobstrução de vias e
proteção de encostas;
IV – atuação integrada com concessionárias e órgãos externos para
restabelecimento de serviços essenciais.
Art. 8º. Este Decreto entra em vigor na data de sua publicação e
vigorará por 90 (noventa) dias, podendo ser prorrogado mediante
justificativa técnica do Comitê e ato do Chefe do Poder Executivo, se
persistirem as condições que o motivaram.
Art. 9º. As Secretarias Municipais expedirão, no que couber, atos
complementares para execução deste Decreto.
Engenheiro Paulo de Frontin, 05 de janeiro de 2026.
JOSÉ EMMANOEL RODRIGUES ARTEMENKO
Prefeito Municipal
Publicado por:
Leonardo Siqueira Castro da Silva
