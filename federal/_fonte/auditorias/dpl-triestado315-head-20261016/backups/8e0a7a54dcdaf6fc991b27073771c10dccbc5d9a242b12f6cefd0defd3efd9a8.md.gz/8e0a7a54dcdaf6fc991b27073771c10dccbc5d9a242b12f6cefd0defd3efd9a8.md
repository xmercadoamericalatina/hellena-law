---
titulo: "Decreto nº 229, de 6 de Dezembro de 1894"
tipo: "Decreto do Poder Legislativo"
numero: "229"
data: 1894-12-06
ementa: "Manda contar ao capitão de cavallaria Antonio Lago, como tempo de effectivo serviço, o periodo decorrido de 28 de fevereiro de 1867 a 27 de agosto de 1873, em que esteve fóra das fileiras do Exercito em consequencia de ferimento recebido em combate."
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-229-6-dezembro-1894-540428-publicacaooriginal-40669-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-229-6-dezembro-1894-540428-norma-pl.html"
baixado_em: 2026-10-15
urn: "urn:lex:br:federal:decreto.legislativo:1894-12-06;229"
---

# Decreto nº 229, de 6 de Dezembro de 1894

Manda contar ao capitão de cavallaria Antonio Lago, como tempo de effectivo serviço, o periodo decorrido de 28 de fevereiro de 1867 a 27 de agosto de 1873, em que esteve fóra das fileiras do Exercito em consequencia de ferimento recebido em combate.

O Presidente da Republica dos Estados Unidos do Brazil:

Faço saber que o Congresso Nacional decretou e eu sancciono a seguinte resolução:

**Art. 1º** Fica o Governo autorisado a mandar contar ao capitão do 8º regimento de cavallaria Antonio Lago, com tempo de effectivo serviço, o periodo decorrido de 28 de fevereiro de 1867 a 27 de agosto de 1873, em que esteve fóra das fileiras do Exercito em consequencia de grave ferimento recebido em combate, mas durante o qual prestou, entretanto, serviços compativeis com seu estado de saude.

**Art. 2º** Revogam-se as disposições em contrario.

O General de Divisão Bernardo Vasques, Ministro de Estado dos Negocios da Guerra, assim o tenha entendido e faça executar.

Capital Federal, 6 de dezembro de 1894, 6º da Republica.

Prudente J. De Moraes Barros.  
Bernardo Vasques.
