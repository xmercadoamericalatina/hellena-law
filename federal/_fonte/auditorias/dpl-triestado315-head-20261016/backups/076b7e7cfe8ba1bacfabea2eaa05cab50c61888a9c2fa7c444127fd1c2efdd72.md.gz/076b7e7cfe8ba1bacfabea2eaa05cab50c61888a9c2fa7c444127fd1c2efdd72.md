---
titulo: "Decreto nº 390, de 2 de Outubro de 1896"
tipo: "Decreto do Poder Legislativo"
numero: "390"
data: 1896-10-02
ementa: "Manda contar de 16 de abril de 1894 a antiguidade de posto dos officiaes da Armada promovidos por decreto de 30 de agosto do mesmo anno."
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-390-2-outubro-1896-540202-publicacaooriginal-40159-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-390-2-outubro-1896-540202-norma-pl.html"
baixado_em: 2026-10-15
urn: "urn:lex:br:federal:decreto.legislativo:1896-10-02;390"
---

# Decreto nº 390, de 2 de Outubro de 1896

Manda contar de 16 de abril de 1894 a antiguidade de posto dos officiaes da Armada promovidos por decreto de 30 de agosto do mesmo anno.

O Presidente da Republica dos Estados Unidos do Brazil: Faço saber que o Congresso Nacional decretou e eu sancciono a resolução seguinte:

**Art. 1º** A antiguidade do posto dos officiaes do corpo da Armada, promovidos por decreto de 30 de agosto de 1894, por serviços prestados á Republica, é contada de 16 de abril do mesmo anno.

**Art. 2º** Revogam-se as disposições em contrario.

Capital Federal, 2 de outubro de 1896, 8º da Republica.

Prudente J. De Moraes Barros.  
Elisiario José Barbosa.
