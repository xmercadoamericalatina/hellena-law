---
titulo: "Decreto nº 126, de 18 de Novembro de 1892"
tipo: "Decreto do Poder Legislativo"
numero: "126"
data: 1892-11-18
ementa: "Autorisa o Poder Executivo a entrar em accordo com a Companhia S. Paulo Railway, limited, no sentido de modificar os contractos existentes."
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-126-18-novembro-1892-541380-publicacaooriginal-44947-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-126-18-novembro-1892-541380-norma-pl.html"
baixado_em: 2026-10-15
urn: "urn:lex:br:federal:decreto.legislativo:1892-11-18;126"
---

# Decreto nº 126, de 18 de Novembro de 1892

Autorisa o Poder Executivo a entrar em accordo com a Companhia S. Paulo Railway, limited, no sentido de modificar os contractos existentes.

O Vice-Presidente da Republica dos Estados Unidos do Brazil:

Faço saber que o Congresso Nacional decreta e eu sancciono a seguinte resolução:

**Art. 1º** Fica o Poder Executivo autorisado a entrar em accordo com a Companhia S. Paulo Railway, limited, no sentido de modificar os contractos existentes, podendo ampliar definitivamente o prazo da encampação.

**Art. 2º** Revogam-se as disposições em contrario.

O Ministro de Estado dos Negocios da Agricultura, Commercio e Obras Publicas assim o faça executar.

Capital Federal, 18 de novembro de 1892, 4º da Republica.

Floriano Peixoto.  
Serzedello Corrêa.
