---
titulo: "Decreto nº 132, de 25 de Maio de 1893"
tipo: "Decreto do Poder Legislativo"
numero: "132"
data: 1893-05-25
ementa: "Autorisa o Poder Executivo a conceder á Empreza Industrial de Melhoramentos no Brazil privilegio para construcção, uso e goso de um ramal no traçado de sua concessão da Estrada de Ferro de S. Francisco Xavier ao Commercio."
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-132-25-maio-1893-540898-publicacaooriginal-42412-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-132-25-maio-1893-540898-norma-pl.html"
baixado_em: 2026-10-15
urn: "urn:lex:br:federal:decreto.legislativo:1893-05-25;132"
---

# Decreto nº 132, de 25 de Maio de 1893

Autorisa o Poder Executivo a conceder á Empreza Industrial de Melhoramentos no Brazil privilegio para construcção, uso e goso de um ramal no traçado de sua concessão da Estrada de Ferro de S. Francisco Xavier ao Commercio.

O Vice-Presidente da Republica dos Estados Unidos do Brazil:

Faço saber que o Congresso Nacional decreta e eu sancciono a seguinte resolução:

**Art. 1º** Fica o Governo autorisado a conceder á Companhia Industrial de Melhoramentos no Brazil privilegio para construcção, uso e goso de um ramal que partindo da Estiva, no traçado da sua concessão da Estrada de Ferro de S. Francisco Xavier ao Commercio, vá á cidade do Mar na estação de S. Pedro, da Estrada de Ferro Leopoldina, ramal de Serraria, com os favores de sua primitiva concessão e sem garantia de juros.

**Art. 2º** Revogam-se as disposições em contrario.

O Ministro de Estado dos Negocios da Industria, Viação e Obras Publicas assim o faça executar.

Capital Federal, 25 de maio de 1893, 5º da Republica.

Floriano Peixoto.  
A. F. Paula Souza.
