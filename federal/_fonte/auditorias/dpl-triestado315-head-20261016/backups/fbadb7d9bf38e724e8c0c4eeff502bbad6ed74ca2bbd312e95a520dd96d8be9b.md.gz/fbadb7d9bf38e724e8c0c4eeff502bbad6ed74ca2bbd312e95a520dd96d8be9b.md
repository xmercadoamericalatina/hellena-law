---
titulo: "Decreto nº 90, de 27 de Setembro de 1892"
tipo: "Decreto do Poder Legislativo"
numero: "90"
data: 1892-09-27
ementa: "Autorisa o Poder Executivo a abrir um credito supplementar de 540:000$000 á verba do n. 17 do art. 7º da lei n. 26 de 30 de dezembro de 1891."
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-90-27-setembro-1892-541338-publicacaooriginal-44832-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-90-27-setembro-1892-541338-norma-pl.html"
baixado_em: 2026-10-15
urn: "urn:lex:br:federal:decreto.legislativo:1892-09-27;90"
---

# Decreto nº 90, de 27 de Setembro de 1892

Autorisa o Poder Executivo a abrir um credito supplementar de 540:000$000 á verba do n. 17 do art. 7º da lei n. 26 de 30 de dezembro de 1891.

O Vice-Presidente da Republica dos Estados Unidos do Brazil: Faço saber que o Congresso Nacional decretou e eu sancciono a seguinte resolução:

**Art. 1º** Fica o Poder Executivo autorisado a abrir um credito supplementar de 540:000$000 á verba do n. 17 do art. 7º da lei n. 26 de 30 de dezembro de 1891.

**Art. 2º** Revogam-se as disposições em contrario.

O Ministro de Estado dos Negocios da Guerra assim o tenha entendido e faça executar.

Capital Federal, 27 de setembro de 1892, 4º da Republica.

Floriano Peixoto.  
Francisco Antonio de Moura.
