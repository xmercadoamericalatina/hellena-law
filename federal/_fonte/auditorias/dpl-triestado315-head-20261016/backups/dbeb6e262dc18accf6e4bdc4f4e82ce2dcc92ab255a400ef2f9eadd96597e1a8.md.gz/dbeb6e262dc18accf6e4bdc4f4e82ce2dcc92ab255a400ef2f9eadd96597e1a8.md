---
titulo: "Decreto nº 219, de 10 de Novembro de 1894"
tipo: "Decreto do Poder Legislativo"
numero: "219"
data: 1894-11-10
ementa: "Releva a D. Maria dos Santos Lucas a prescripção em que incorreu para perceber o meio soldo a que tem direito de 1853 a 1892."
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-219-10-novembro-1894-540365-publicacaooriginal-40558-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-219-10-novembro-1894-540365-norma-pl.html"
baixado_em: 2026-10-15
urn: "urn:lex:br:federal:decreto.legislativo:1894-11-10;219"
---

# Decreto nº 219, de 10 de Novembro de 1894

Releva a D. Maria dos Santos Lucas a prescripção em que incorreu para perceber o meio soldo a que tem direito de 1853 a 1892.

O Vice-Presidente da Republica dos Estados Unidos do Brazil:

Faço saber que o Congresso Nacional decreta e eu sancciono a seguinte resolução:

Artigo unico. Fica relevada a prescripção em que incorreu D. Maria dos Santos Lucas para perceber o meio soldo a que tem direito de 1853 a 1892; revogadas as disposições em contrario.

O General de Divisão Dr. Bibiano Sergio Macedo da Fontoura Costallat, Ministro de Estado da Industria, Viação e Obras Publicas e encarregado do expediente do Ministerio da Guerra, assim o tenha entendido e faça executar.

Capital Federal, 10 de novembro de 1894, 6º da Republica.

Floriano Peixoto.  
Bibiano Sergio Macedo da Fontoura Costallat.
