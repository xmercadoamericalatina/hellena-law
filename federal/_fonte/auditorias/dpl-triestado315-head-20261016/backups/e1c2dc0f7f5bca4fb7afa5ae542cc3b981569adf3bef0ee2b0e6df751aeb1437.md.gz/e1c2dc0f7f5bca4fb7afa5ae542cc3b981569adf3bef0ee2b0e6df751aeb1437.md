---
titulo: "Decreto nº 339, de 28 de Novembro de 1895"
tipo: "Decreto do Poder Legislativo"
numero: "339"
data: 1895-11-28
ementa: "Autorisa o Poder Executivo a permittir á Companhia Brasil Great Southern Railway, a construcção da ponte sobre o rio Quarahim, no Rio Grande do para ligar a Estrada de Ferro Quarahim a Itaqui á ferro-via Oriental do Salto a Santa Rosa."
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-339-28-novembro-1895-540836-publicacaooriginal-42208-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-339-28-novembro-1895-540836-norma-pl.html"
baixado_em: 2026-10-15
urn: "urn:lex:br:federal:decreto.legislativo:1895-11-28;339"
---

# Decreto nº 339, de 28 de Novembro de 1895

Autorisa o Poder Executivo a permittir á Companhia Brasil Great Southern Railway, a construcção da ponte sobre o rio Quarahim, no Rio Grande do para ligar a Estrada de Ferro Quarahim a Itaqui á ferro-via Oriental do Salto a Santa Rosa.

O Presidente da Republica dos Estados Unidos do Brazil:  
Faço saber que o Congresso Nacional decretou e ou sancciono a resolução seguinte:

**Art. 1º** E' o Poder Executivo autorisado a permittir á Companhia Brasil Great Southern Railway a construcção da ponte sobre o rio Quarahim, no Rio Grande do Sul, afim de ligar a Estrada de Ferro Quarahim a Itaqui á ferro-via Oriental do Salto a Santa Rosa, estatuindo no respectivo contracto as condições necessarias a garantir os interesses aduaneiros da Republica.

**Art. 2º** Revogam-se as disposições em contrario.

Capital Federal, 28 de novembro de 1895, 7º da Republica.

Prudente J. de Moraes Barros.  
Antonio Olyntho dos Santos Pires.
