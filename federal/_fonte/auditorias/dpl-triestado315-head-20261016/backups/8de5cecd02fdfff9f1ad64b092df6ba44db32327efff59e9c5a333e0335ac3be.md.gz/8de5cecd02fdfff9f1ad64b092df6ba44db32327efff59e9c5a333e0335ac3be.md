---
titulo: "Decreto nº 214, de 26 de Outubro de 1894"
tipo: "Decreto do Poder Legislativo"
numero: "214"
data: 1894-10-26
ementa: "Approva os decretos ns. 1594 A, 1594 B e 1594 C, de 4, 6 e 7 de novembro do anno findo, 1682 de 28 de fevereiro, 1687 e 1688 de 17 de março do corrente anno."
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-214-26-outubro-1894-540360-publicacaooriginal-40553-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1824-1899/decreto-214-26-outubro-1894-540360-norma-pl.html"
baixado_em: 2026-10-15
urn: "urn:lex:br:federal:decreto.legislativo:1894-10-26;214"
---

# Decreto nº 214, de 26 de Outubro de 1894

Approva os decretos ns. 1594 A, 1594 B e 1594 C, de 4, 6 e 7 de novembro do anno findo, 1682 de 28 de fevereiro, 1687 e 1688 de 17 de março do corrente anno.

O Vice-Presidente da Republica dos Estados Unidos do Brazil:

Faço saber que o Congresso Nacional decretou e eu sancciono a seguinte resolução:

Artigo unico. Ficam approvados, e como taes considerados como leis do paiz, com todos os effeitos, desde sua decretação, os decretos ns. 1594 A, 1594 B e 1594 C, de 4, 6 e 7 de novembro do anno findo, 1682 de 28 de fevereiro, 1687 e 1688 de 17 de março do corrente anno.

Capital Federal, 26 de outubro de 1894, 6º da Republica.

Floriano Peixoto.  
Cassiano do Nascimento.  
Bibiano Sergio Macedo da Fontoura Costallta.
