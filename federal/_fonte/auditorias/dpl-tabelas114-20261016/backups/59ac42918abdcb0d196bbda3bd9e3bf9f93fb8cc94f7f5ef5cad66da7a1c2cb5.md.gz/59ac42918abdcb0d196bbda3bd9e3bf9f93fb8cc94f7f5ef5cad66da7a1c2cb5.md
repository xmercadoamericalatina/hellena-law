---
titulo: "Decreto nº 3.221, de 3 de Janeiro de 1917"
tipo: "Decreto do Poder Legislativo"
numero: "3221"
data: 1917-01-03
ementa: "Autoriza a abrir pelo Ministerio da Fazenda, os creditos especiaes de réis 1.047:846$974, papel, e 532$989, ouro, para o fim de occorrer ao pagamento de dividas de exercicios findos"
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1910-1919/decreto-3221-3-janeiro-1917-572597-publicacaooriginal-95800-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1910-1919/decreto-3221-3-janeiro-1917-572597-norma-pl.html"
baixado_em: 2026-10-16
urn: "urn:lex:br:federal:decreto.legislativo:1917-01-03;3221"
---

# Decreto nº 3.221, de 3 de Janeiro de 1917

Autoriza a abrir pelo Ministerio da Fazenda, os creditos especiaes de réis 1.047:846$974, papel, e 532$989, ouro, para o fim de occorrer ao pagamento de dividas de exercicios findos

O Presidente da Republica dos Estados Unidos do Brazil:  
Faço saber que o Congresso Nacional decretou e eu sancciono a seguinte resolução:

**Art. 1º** E' o Poder Executivo autorizado a abrir, pelo Ministerio da Fazenda, os creditos especiaes de 1.047:846$974, papel, e 532$989, ouro, para o fim de occorrer ao pagamento de dividas de exercicios findos, sendo:

Papel

*a)*

pelo Ministerio da Justiça e Negocios Interiores...................................................... 98:074$918

*b)*

pelo Ministerio da Marinha..................................................................................... 201:196$098

*c)*

pelo Ministerio da Guerra....................................................................................... 497:124$058

*d)*

pelo Ministerio da Viação e Obras Publicas............................................................ 4:495$760

*e)*

pelo Ministerio da Agricultura, Industria e Commercio............................................. 63:441$936

*f)*

pelo Ministerio da Fazenda......................................................................................183:514$204

E o credito em ouro de ................................................................................................ 532$989

**Art. 2º** Revogam-se as disposições em contrario.

Rio de Janeiro, 3 de janeiro de 1917, 96º da Independencia e 29º da Republica.

WENCESLAU BRAZ P. GOMES.  
João Pandiá Calogeras.
