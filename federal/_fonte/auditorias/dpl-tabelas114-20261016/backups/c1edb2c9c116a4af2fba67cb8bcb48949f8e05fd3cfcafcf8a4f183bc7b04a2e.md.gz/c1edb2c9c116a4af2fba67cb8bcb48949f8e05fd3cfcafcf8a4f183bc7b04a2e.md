---
titulo: "Decreto nº 2.862, de 15 de Agosto de 1914"
tipo: "Decreto do Poder Legislativo"
numero: "2862"
data: 1914-08-15
ementa: "Suspende, por 30 dias, em todo o territorio da Republica, o vencimento das obrigações resultantes de letras de cambio e outros titulos commerciaes, e dá outras providencias"
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1910-1919/decreto-2862-15-agosto-1914-575491-publicacaooriginal-98691-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1910-1919/decreto-2862-15-agosto-1914-575491-norma-pl.html"
baixado_em: 2026-10-16
urn: "urn:lex:br:federal:decreto.legislativo:1914-08-15;2862"
---

# Decreto nº 2.862, de 15 de Agosto de 1914

Suspende, por 30 dias, em todo o territorio da Republica, o vencimento das obrigações resultantes de letras de cambio e outros titulos commerciaes, e dá outras providencias

O Presidente da Republica dos Estados Unidos do Brazil:  
Faço saber que o Congresso Nacional decretou e eu sancciono a seguinte resolução:

**Art. 1º** Ficam suspensos em todo o territorio da Republica, pelo prazo de 30 dias, contados da data do respectivo vencimento, desde que este occorra dentro do referido prazo, que o Governo poderá prorogar por uma ou mais vezes até o maximo de mais 120 dias:

*a)*

a exigibilidade das obrigações resultantes de letras de cambio, de notas promissorias ou de quaesquer outros titulos commerciaes e bem assim das prestações por dividas hypothecarias ou pignoraticias, não se comprehendendo na suspensão:

I. As retiradas de depositos que não vencem juros.  
II. As retiradas de 10% mensaes dos depositos em contas correntes que vencem juros.  
III. As retiradas de 50%, quando feitas pela União ou pelos Estados.

*b)*

os protestos, recursos em garantias e prescripções dos referidos titulos;

*c)*

o andamento dos executivos para a cobrança de impostos federaes e, no Districto Federal, para a de impostos municipaes;

*d)*

a troca por ouro das notas da Caixa de Conversão, podendo, porém, dentro dos prazos deste artigo, o Governo resolve que a suspensão seja continua ou intermittente ou permittir a troca de quantias diariamente prefixadas.

**Art. 2º** O ouro existente na Caixa de Conversão continuará em deposito, para o fim exclusivo da troca das notas por ella emittidas, mantidas contra qualquer desvio as garantias e penalidades estatuidas pela lei n. 1.575, de 6 de dezembro de 1906.

**Art. 3º** Não são abrangidas pelos effeitos desta lei as operações a prazo effectuadas depois do dia de sua publicação.

**Art. 4º** Fica approvado o decreto de 3 de agosto corrente que estabeleceu férias de 4 a 15 do mesmo mez, apenas sustados os despejos, as acções executivas, as execuções e as declarações de fallencia e relevadas as prescripções de quaesquer prazos que durante a sua applicação tenham occorrido.

Paragrapho unico. São validos as escripturas, contractos e mais actos judiciaes e forenses praticados durante os dias a que se refere este artigo.

**Art. 5º** Cessará a moratoria para os bancos nacionaes e estrangeiros logo que houverem recebido do Estado auxilio pecuniario por meio de emissão ou qualquer outro e para os credores do Thesouro logo que hajam recebido a importancia de suas contas.

**Art. 6º** Esta lei entrará em vigor no Districto Federal no mesmo dia de sua publicação no Diario Official.

Paragrapho unico. O Poder Executivo providenciará para que seja o respectivo texto transmittido por via telegraphica aos presidentes e gorvenadores dos Estados, afim de que, ordenada a publicação local, comece immediatamente a execução nas comarcas das respectivas capitaes e nas outras comarcas no mesmo dia da publicação feita em audiencia pelo juiz de direito.

**Art. 7º** Revogam-se as disposições em contrario.

Rio de Janeiro, 15 de agosto de 1914, 93º da Independencia e 26º da Republica.

HERMES R. DA FONSECA.  
Herculano de Freitas.
