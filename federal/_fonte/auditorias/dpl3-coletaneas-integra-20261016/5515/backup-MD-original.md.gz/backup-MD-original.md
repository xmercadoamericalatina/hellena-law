---
titulo: "Decreto nº 5.515, de 13 de Agosto de 1928"
tipo: "Decreto do Poder Legislativo"
numero: "5515"
data: 1928-08-13
ementa: "Restabelece, no Districto Federal, o inquerito policial, e dá outras providencias"
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1920-1929/decreto-5515-13-agosto-1928-562444-publicacaooriginal-86469-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1920-1929/decreto-5515-13-agosto-1928-562444-norma-pl.html"
baixado_em: 2026-10-16
urn: "urn:lex:br:federal:decreto.legislativo:1928-08-13;5515"
---

# Decreto nº 5.515, de 13 de Agosto de 1928

Restabelece, no Districto Federal, o inquerito policial, e dá outras providencias

O Presidente da Republica dos Estados Unidos do Brasil:

Faço saber que o Congresso Nacional decretou e eu sancciono a resolução seguinte:

**Art. 1º** Fica restabelecido, no Districto Federal, o inquerito policial, obedecendo-se ás disposições do decreto numero 16.751, de 31 de dezembro de 1924, no que não fôr por esta lei modificado.

**Art. 2º** As autoridades policiaes, ao terem, por qualquer meio, conhecimento da pratica de um crime de acção publica, procederão, immediatamente, ás diligencias necessarias á sua elucidação e ao descobrimento dos seus autores e cumplices, reduzindo-as a escripto em um só processado, abrangendo todas as peças que formam actualmente os autos de investigação e inquirição referidos no decreto mencionado no artigo anterior.

**Art. 3º** O inquerito policial poderá ser iniciado:

I - a requerimento do Ministerio Publico, da parte offendida ou de quem tiver qualidade para represental-a;

II - por aviso de qualquer pessoa do povo (art. 4º);

III - por determinação das autoridades policiaes.

Paragrapho unico. O requerimento da parte offendida ou de quem tiver qualidade para represental-a deverá conter:

I - a narração do facto delictuoso, com todas as circumstancias, inclusive as de tempo e logar;

II - a individuação do indiciado, com os signaes caracteristicos, si fôr desconhecido, ou os motivos de impossibilidade de o fazer, e a srazões de convição ou presumpção de ser elle o autor do delicto;

III - a nomeação das testemunhas, com indicação de sua profissão e residencia.

**Art. 4º** Qualquer pessoa do povo, que souber da existencia de crime ou contravenção, poderá verbalmente ou por escripto, dirigir-se á autoridade policial que, verificando a procedencia das informações, mandará tomal-as por termo, e proseguirá nas diligencias indispensaveis á apuração da verdade.

**Art. 5º** O pedido de abertura de inquerito poderá ser indeferido, si não encontrar base para inicial-o a autoridade a quem a petição fôr dirigida. Paragrapho unico. Deste despacho haverá recurso para o Chefe de Policia, de cuja decisão não caberá recurso algum.

**Art. 6º** No caso de infracção penal cujos vestigios possam ser, de qualquer modo, examinados, a autoridade policial, nos crimes de acção publica, procederá immediatamente a corpo de delicto.

**Art. 7º** Os exames enumerados no art. 195 do Codigo do Processo Penal deste Districto serão feitos por dois medicos legistas designados pela autoridade policial que tiver de presidir ao inquerito, a qual os encarregará de examinar e descrever com verdade e com todas as circumstancias o que encontrarem, descobrirem ou observarem.

**§ 1º** Si a victima do crime não fôr ou não puder ser transportada á Policia ou á séde do Instituto Medico Legal, ou si o crime fôr de natureza tal que os vestigios só possam ser examinados no logar em que foi perpetrado, a autoridade policial, a cujo conhecimento chegar a noticia do crime, ordenará incontinenti aos medicos legistas que se transportem ao logar onde ella estiver para proceder immeditamente a exaem de corpo de delicto.

**§ 2º** O corpo de delicto, feito pelo medico ou medicos legistas, será immediatamente reduzido a auto, escripto ou dactylographado, pelo escrivão ou escrevente da delegacia e assignado pelos peritos.

**Art. 8º** Quando fôr impossivel o corpo de delicto directo, porque a infracção penal não tenha deixado vestigio, ou della sómente se tiver noticia, quando ella já não exista, as testemunhas serão inqueridas a respeito da existencia do crime com todos os pormenores, e tambem acerca do criminoso.

**Art. 9º** A autoridade que presidir ao corpo de delicto, deverá exigir que os peritos escrevam com clareza os seus relatorios e respostas, afim de que os escrivães lhes copiem com acerto os termos scientificos.

**Art. 10.** Si os peritos não puderem formar logo juizo seguro ou fazer relatorio completo de suas investigações, ser-lhes-á marcado, para este fim, ou para procederem a novo exame, si o exigirem as circumstancias, um prazo não excedente de cinco dias.

Paragrapho unico. Nos casos em que se façam necessarios exames histologicos, chimicos ou outros de execução igualmente demorada, poderão ser marcados aso peritos prazos mais longos, desde que o requeiram motivadamente, proseguindo o inquerito, independente da terminação do exame.

**Art. 11.** Os autos de exames constarão de preambulo, exposição e conclusão, nos termos do regulamento que se baixar e de accôrdo com os modelos organizados pelo Instituto Medico Legal e adoptados pela Chefatura de Policia.

**Art. 12.** Ao perito que, sem justa causa, não comparecer, após a notificação, ao logar onde se tenha de proceder a exame de corpo de delicto, poderá o Chefe de Policia impôr multa de 100$, descontada nos respectivos vencimentos, si o perito fôr funccionario publico.

**Art. 13.** Julgar-se-á procedente o corpo de delicto, quando a diligencia houver sido executada com observancia de todas as formalidades legaes e todas as cautelas necessarias á validade da pesquiza; e improcedente, no caso contrario. A primeira decisão será final; cabendo recurso da segunda para a autoridade judiciaria competente.

**Art. 14.** As emendas, entrelinhas ou razuras devem ser sempre resalvadas no fim do auto, antes de assignado.

**Art. 15.** O exame de corpo de delicto poderá ser procedido por determinação de qualquer autoridade policial, embora de districto alheio ao da culpa, devendo, neste caso, após o julgamento daquelle se remetter o auto, para os fins de direito, á autoridade em cuja jurisdicção o facto tiver occorrido.

**Art. 16.** Nos exames de sanidade mental, poderão os peritos requisitar e o juiz competente ordenar, o internamento provisorio do examinando em estabelecimento apropriado, afim de se fazerem as observações convenientes.

**Art. 17.** Nos crimes de que não caiba denuncia, serão entregues á parte, sem que fique traslado, os exames procedidos a seu requerimento, pagas as custas.

**Art. 18.** Na primeira occasião em que o indiciado comparecer perante á autoridade policial, ser-lhe-á perguntado o nome, a filiação, a idade, o estado, a profissão, a naturalidade, a residencia e si sabe lêr e escrever, lavrando-se das perguntas e respostas o respectivo auto de qualificação.

Paragrapho unico. A autoridade, sempre que fôr possivel, tomará por termo as declarações do indiciado, que as assignará, ou alguem a seu rogo, com duas testemunhas idoneas, estranhas á Policia.

**Art. 19.** No caso de prisão em flagrante, todas as diligencias do inquerito serão concluidas no prazo improrogavel de oito dias, devendo o indiciado e seu procurador, si o tiver, assistir á inquirição das testemunhas, podendo contestar-Ihes o depoimento e requerer sejam perguntadas sobre tudo quanto se relacionar com o direito de defesa.

Paragrapho unico. Si o juiz, durante o prazo fixado neste artigo, por qualquer motivo, requisitar os autos, considerar-se-á encerrado o inquerito, que deverá ser, então, pela autoridade judiciaria, dado com vistas ao Ministerio Publico, para os fins de direito.

**Art. 20.** Não havendo flagrante delicto, o inquerito deverá estar concluido dentro de 20 dias.

**Art. 21.** Quando, porém, o facto fôr de difficil elucidação, a autoridade, depois de 30 dias de pesquizas, enviará os autos, com o resultado a que tiver chegado ao juiz competente, podendo requerer-lhe a devolução dos mesmos para ulteriores diligencias.

**Art. 22.** As testemunhas do inquerito serão ouvidas cada uma de per si, precedendo ao depoimento o respectivo termo de assentada.

**Art. 23.** Nos crimes inaffiançaveis, compete á autoridade policial representar, quanto antes, sobre a necessidade ou conveniencia da prisão preventiva, requerendo a devolução dos autos para diligencias complementares, cujo prazo não poderá exceder de oito dias. Estas representações serão sempre fundamentadas.

**§ 1º** Recebidas e distribuidas, sem perda de tempo, os autos de inquerito policial, a autoridade judiciaria ordenará ao respectivo escrivão que assigne o recibo no livro de carga da Policia e, independente de parecer do Ministerio Publico, dntro de 24 horas, concederá ou denegará a prisão preventiva.

**§ 2º** Deste despacho será notificada immediatamente a autoridade policial.

**Art. 24.** Terminadas as diligencias do inquerito serão os autos conclusos á autoridade policial, que os relatará com clareza e precisão, recapitulando tudo quanto fôr averiguado e ordenará a remessa dos mesmos ao juiz competente.

**Art. 25.** No relatoria poderá a autoridade indicar testemunhas, que não foram inqueridas, bem assim o logar onde possam ser encontradas.

**Art. 26.** Si, para o proseguimento ou a conclusão do procedimento criminal, necessitar o juiz de indicação de testemunhas e informações relativas ao seu paradeiro e ao dos autores e cumplices da infracção penal, e verificação da identidade destes e daquelles, poderá pedil-as por officio á autoridade policial que presidiu ao inquerito.

Paragrapho unico. O Ministerio Publico não poderá requerer sinão uma vez a devolução do inquerito á Policia para novas diligencias. Cumpridas estas, si necessitar de outras, requerel-as-ha ao juiz, que, si as considerar necessarias deferirá o requerimento, ordenando, porém, que sejam (Ilegível) em auto apartado, e sem devolução do inquerito que servirá de base, á apresentação immediata da denuncia.

**Art. 27.** São permittidos, por ordem do Chefe de Policia, o inquerito em segredo de justiça e a incommunicabilidade do indiciado, quando o interesse da sociedade, ou a conveniencia da investigação o exigir, sendo, nestes casos, prohibida qualquer publicação.

Paragrapho unico. A incompmunicabilidade não poderá exceder de 24 horas.

**Art. 28.** Nos inqueritos policiaes ex-officio é permittida a inerveção, com assistente de terceiro, que mostre interesse na apuração da responsabilidade civil dos indigitados autores ou cumplices do damno.

**Art. 29.** Sempre que estiver provada no inquerido a autoria do delicto, poderá a autoridade policial, depois da respectiva avaliação, entregar ao seu legitimo dono, as cousas apprehendidas, fazedo lavrar o "auto de entrega", que assignará com o proprietario duas testemunhas e o escrivão; quando, porém, não estiver sufficientemente provada a propriedade das coisas apprehendidas, a autoridade as remetterá, com os autos, ao juiz, para decidir.

**Art. 30.** As peças do inquerito policial poderão ser impressas ou dactylographadas, rubricadas, porém, cada folha pela autoridade competente.

**Art. 31.** São prohibidas entre autoridades policiaes, judiciarias e membros do Ministerio Publico, expressões, nos autos, que envolvam censura, offensa ou imcoveniencia de linguagem, podendo os interessados, mediante representação ao presidente da Côrte de Appellação, requerer sejam as mesmas riscadas. Neste caso, requisitados incontinente os autos, compete ao presidente da Côrte de Appellação mandar riscar as expressões julgadas inconvenientes ou offensivas.

Paragrapho unico. As autoridades judiciarias. policiaes e membros do Ministerio Publico serão, neste caso, respectivamente censurados em oficio, pelo presidente da Côrte de Appelalção, Chefe de Policia e procurador Geral, incorrendo em suspensão, até 90 dias, o funccionario reincidente.

**Art. 32.** A acção penal póde ser inciada por queixa, denuncia ou ex-officio, independente de inquerito policial.

Paragrapho unico. Nos crimes de responsabilidade dos funccionarios publicos, sob pena de nullidade, a denuncia será sempre instruida pelo inquerido policial ou administrativo.

**Art. 33.** O nquerito policial, quando concluido ou no caso do art. 19, paragrapho unico. acompanhará sempre a denuncia ou queixa, iniciadora da acção penal, e, merecendo valor até prova em contrario, será incorporado aos autos do processo.

**Art. 34.** A attribuição constante do art. 126, § 3º, do decreto n. 16.273, de 20 de dezembro de 1923, passará a ser exercida pelo Chefe de Policia ou por um dos delegados auxiliares por elle designado, ficando abolida a intervenção a que se refere o citado dispositivo.

**Art. 35.** As autoridades policiaes, os peritos e outros funccionarios da Policia, que intervierem directa ou indirectamente no inquerito, não serão obrigados a depôr, na formação da culpa, exceptuando-se os conductores e as testemunhas que depuzeram.

**Art. 36.** Ficam abolidas para os actos do inquerito policial, as requisições de funccionarios publicos, podendo a autoridade policial providenciar directamente sobre a intimação e o comparecimento dos mesmos, como testemunhas indiciados ou peritos.

**Art. 37.** As testemunhas que não comparecerem, sem motivo justificado, serão, depois de novamente intimadas, conduzidas, mediante mandado escripto da autoridade policial, até a sua presença, e incorrerão em crime de desobediencia.

Paragrapho unico. Na mesma pena incorrerão os indiciados, presos em flagrante, que se negarem a ser identificados.

**Art. 38.** Passarão a ser subordinados administrativamente ao Chefe de Policia o actual Instituto Medico-Legal e Gabinete de Identificação e Estatistica.

**Art. 39.** Ficam extensivas ao 4º delegado auxiliar as atribuições conferidas aos outros delegados auxiliares pelo art. 33 do decreto n. 6.440, de 30 de março de 1907, sem prejuizo das que lhe são inherentes, em virtude do disposto no art. 5º do regulamento que baixou com o decreto numero 15.848, de 20 de novembro de 1922.

Paragrapho unico. Ficam creados na 4ª Delegacia Auxiliar os cargos de um escrivão e tres escreventes, com os vencimentos actuaes.

**Art. 40.** Nos regulamentos para os serviços dependentes da Policia poderão ser estabelecidas multas de 10$ a 200$, as quaes, esgotados os recursos regulamentares, serão cobra-das executivamente.

**Art. 41.** Fica o Governo autorizado a rever os regimentos de custas policiaes e os regulamentos de todas as repartições dependentes da Policia, supprimindo, reduzindo, augmentando ou creando emolumentos e custas, que continuarão a ser cobrados em estampilhas federaes.

**Art. 42.** Na repressão das contravenções, punidas pelos arts. 31 e 32 da lei n. 2.321, de 1910, será, applicado o disposto na parte final da alinea do art. 369 do Codigo Penal da Republica.

**Art. 43.** Os interdictos possessorios não protegerão crimes, nem contravenções, nem caberão contra actos do Chefe de Policia, praticados no exercicio de suas attribuições administrativas ou preventivas.

Paragrapho unico. Commetterá o crime previsto no artigo 207, n. 1, do Codigo Penal, a autoridade judiciaria que proceder contra sete artigo.

**Art. 44.** As autoridades e funccionarios da Policia Civil são demissiveis da-nutum.

**Art. 45.** Revogam-se as disposições em contrario.

Rio de Janeiro, em 13 de agosto de 1928, 107º da Independencia e 40º da Republica.

WASHINGTON LUIS P. DE SOUSA  
Augusto de Vianna do Castello
