---
titulo: "Decreto nº 5.488, de 9 de Julho de 1928"
tipo: "Decreto do Poder Legislativo"
numero: "5488"
data: 1928-07-09
ementa: "Autoriza o Governo a abrir, pelo Ministerio da Justiça e Negocios Interiores, os creditos de 37:300$000 e 540$000, para pagamento da differença da gratificação de que trata o decreto n. 3.990, de 2 de janeiro de 1920, aos motoristas do Departamento Nacional de Saude Publica, e da differença de gratificação addicional ao tachygrapho do Senado Federal, Mario Pollo, respectivamente"
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1920-1929/decreto-5488-9-julho-1928-562431-publicacaooriginal-86450-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1920-1929/decreto-5488-9-julho-1928-562431-norma-pl.html"
baixado_em: 2026-10-16
urn: "urn:lex:br:federal:decreto.legislativo:1928-07-09;5488"
---

# Decreto nº 5.488, de 9 de Julho de 1928

Autoriza o Governo a abrir, pelo Ministerio da Justiça e Negocios Interiores, os creditos de 37:300$000 e 540$000, para pagamento da differença da gratificação de que trata o decreto n. 3.990, de 2 de janeiro de 1920, aos motoristas do Departamento Nacional de Saude Publica, e da differença de gratificação addicional ao tachygrapho do Senado Federal, Mario Pollo, respectivamente

O Presidente da Republica dos Estados Unidos do Brasil: Faço saber que o Congresso Nacional decretou e eu sancciono a resolução seguinte:

**Art. 1º** E' o Governo autorizado a abrir o credito de 37:300$000, para pagar aos motoristas de 2ª classe do Departamento Nacional de Saude Publica a gratificação a (ilegível) teem direito, pelo decreto n. 3.990, de 2 de janeiro de 1920, no periodo de outubro de 1920 a junho de 1922.

**Art. 2º** Fica igualmente o Poder Executivo autorizado a abrir, pelo Ministerio da Justiça, o credito especial de 540$000, para pagamento da differença de gratificação addicional a que tem direito o tachygrapho de 1ª classe do Senado Federal, Mario Pollo, de 10 de março de 1927, data de sua promoção a essa classe, a 31 de dezembro de 1927.

**Art. 3º** Revogam-se as disposições em contrario.

Rio de Janeiro, 9 de julho de 1928, 107º da Independencia e 40º da Republica.

WASHINGTON LUIS P. DE SOUSA.  
Augusto de Vianna do Castello.
