---
titulo: "Decreto nº 4.743, de 31 de Outubro de 1923"
tipo: "Decreto do Poder Legislativo"
numero: "4743"
data: 1923-10-31
ementa: "Regula a liberdade de imprensa e dá outras providencias"
situacao: "Não consta revogação expressa"
revogada: false
versao_texto: "original"
fonte: "https://www2.camara.leg.br/legin/fed/decret/1920-1929/decreto-4743-31-outubro-1923-567758-publicacaooriginal-91090-pl.html"
url_metadados: "https://www2.camara.leg.br/legin/fed/decret/1920-1929/decreto-4743-31-outubro-1923-567758-norma-pl.html"
baixado_em: 2026-10-16
urn: "urn:lex:br:federal:decreto.legislativo:1923-10-31;4743"
---

# Decreto nº 4.743, de 31 de Outubro de 1923

Regula a liberdade de imprensa e dá outras providencias

O Presidente da Republica dos Estados Unidos do Brasil:

Faço saber que o Congresso Nacional decretou e eu sancciono a resolução seguinte:

RESPONSABILIDADES E PENAS

**Art. 1º** Os crimes previstos nos arts. 126, 315 e 317 do Codigo Penal e nos arts. 1º, 2º e 3º do decreto n. 4.269, de 17 de janeiro de 1921, quando commettidos pela imprensa, serão punidos com as seguintes penas:

1.º Nos casos previstos no art. 126 do Codigo Penal - metade da pena correspondente ao crime cuja pratica se tiver provocado.  
2º No caso do art. 315 do Codigo Penal - prisão cellular por quatro mezes a um anno e multa de 1:000$ a 10:000$, elevada a pena para seis mezes a dous annos de prisão cellular e multa de 2:500$ a 10:000$, si o crime fôr contra corporação que exerça autoridade publica, ou contra agente ou depositario desta.  
3º No caso do art. 317, do mesmo Codigo Penal - prisão cellular por dous a seis mezes e multa de 1:000$ a 6:000$, elevada a pena para tres a nove mezes de prisão cellular e multa de 2:000$ a 12:000$ na mesma hypothese prevista na ultima parte do numero precedente.  
4º No caso dos arts. 1º a 3º do decreto n. 4.269, de 17 de janeiro de 1921 - as penas constantes dos mesmos artigos serão accrescidas da multa de 5:000$ a 40:000$000.

**§ 1º** Essas penas serão graduadas pelo julgador, conforme a gravidade da offensa, as condições de fortuna do réo, e o criterio dos arts. 62, 65 e 66 do Codigo Penal. Tratando-se de qualquer dos crimes previstos no artigo 126 do Codigo Penal, nos arts. 1º a 3º do decreto numero 4.269, de 1921, e no art. 2º da presente lei, além das penas nesta estabelecidas, será applicavel, administrativamente, a de expulsão, quando se, tratar de estrangeiros a ella sujeitos.

**§ 2º** Não terá cabimento nesses crimes o disposto no artigo 27, § 6º, e no art. 32 do Codigo Penal.

**§ 3º** A prova do facto imputado é permittida nos casos previstos no art. 318 do Codigo Penal, comprehendidos nesta disposição os senadores, deputados, conselheiros municipaes, intendentes ou prefeitos. Não se admittirá, porém, nos casos de offensas previstas nos arts. 3º e 4º na presente lei.

**Art. 2º** A publicação de segredos do Estado é punida com a pena de prisão cellular por um a quatro annos, tambem applicavel no caso de noticias ou informações relativas á sua força, preparação e defesa militar, si taes noticias ou informações puderem de algum modo influir sobre a sua segurança externa ou despertar rivalidades ou desconfianças, perturbadoras das boas relações internacionaes.

Paragrapho unico. E', entretanto, permittida a discussão e critica si tiver por fim esclarecer e preparar a opinião para as reformas e previdencias convenientes ao interesse publico comtanto que se use de linguagem moderada, leal e respeitosa.

**Art. 3º** A offensa feita pela imprensa ao Presidente da Republica no exercicio de suas funcções ou fóra delle, e a algum soberano ou chefe de Estado estrangeiro, ou aos seus representantes diplomaticos, quando não revista caracteres da calumnia ou injuria, é punida com a pena de prisão cellular por tres a nove mezes e multa de 4:000$ a 20:000$000.

**Art. 4º** E' prohibido, sob pena de multa de 200$ a 4:000$, affixar ou expôr ao publico em qualquer logar e por qualquer meio, inclusive fitas cinematographicas, cartaz, estampa, gravura dcsenho, e em geral impresso, manuscripto ou figura onde haja offensa a ali alguma nação estrangeira.

Paragrapho unico. Fica sujeito á pena de prisão cellular por dous a seis mezes quem apregoar, em logares publicos, a venda de gazetas, papeis e impressos, ou manuscriptos de modo offensivo a pessoa ou nacionalidade certa e determinado com o fim de escandalo e (ilegível).

**Art. 5º** A offensa á moral publica ou aos bons costumes, feita de qualquer modo pela imprensa, é punida com a pena de prisão cellular por seis mezes a dous annos, e da perda do objecto de onde constar a mesma offensa, além da multa de 200$ a 2:000$000.

Paragrapho unico. E' prohibido, sob a mesma pena deste artigo, vender, expôr á venda ou, por algum modo, concorrer para que circule qualquer livro, folheto, periodico, ou jornal, gravura, desenho, estampa, pintura ou impresso de qualquer natureza desde que contenha offensa á moral publica ou aos bons costumes.

**Art. 6º** E' prohibida, sob pena de multa de 100$ a 1:000$, a publicação de annuncios ou noticias relativas a medicamentos não approvados pela Directoria Geral de Saude Publica, ou a tratamentos ou curas não confirmadas por profissionaes.

**Art. 7º** Aquelle que, por qualquer meio, obtiver ou procurar obter dinheiro ou outtro proveito para não fazer ou impedir se faça alguma publicação, é punido com a pena de prisão cellular por um a quatro annos, e multa de 300$ a 6:000$, incorrendo na mesma pena o que, mediante paga ou recompensa, fizer ou obtiver se faça qualquer publicação que importe crime de imprensa punido pela presente lei.

**Art. 8º** Não se consideram crimes:

1\. A publicação, integral ou resumida, dos debates nas Casas Legislativas, federaes, estaduaes ou municipaes, dos relatorios ou qualquer outro escripto, impresso por ordem das mesmas.  
2. O noticiario, o resumo, o relatorio, a resenha e a chronica fieis dos debates e andamento de todos os projectos e assumptos sujeitos ao exame e deliberação das mencionadas corporações.  
3. A publicação integral, parcial ou abreviada, de noticias, chronica ou resenha, quando fieis, dos debates escriptos ou oraes perante juizes e tribunaes, nem tão pouco a publicação dos despachos, sentenças ou quaesquer escriptos que houverem sido impressos mediante ordem, requisição ou communicação dos mesmos juizes e tribunaes.  
4. A pubIicação de articulados, cotas ou allegações produzidas em juizo pelas partes ou seus procuradores.

**Art. 9º** As injurias compensam-se: em consequencia não poderão querelar por injurias os que reciprocamente se injuriarem.

**Art. 10.** Pelos abusos de liberdade de imprensa são responsaveis successivamente:

1º, o autor, sendo pessoa idonea, em condições de responder pecuniariamente pelas multas e despezas judiciaes, e residente no paiz, salvo tratando-se de reproducção feita sem o seu consentimento, caso em que responderá quem a tiver feito;  
2º, o editor, si se verificarem a seu respeito as mesmas condições exigidas em relação ao autor, e este não fôr conhecido, ou não as reunir:  
3º. o dono da officina ou estabelecimento, onde se tiver feito a publicação; e, na sua falta ou ausencia do paiz, quem o estiver representando, desde que se não verifique o disposto em os numeros anteriores;  
4º, os vendedores ou distribuidores, quando não constar quaes sejam ou autores ou editores, nem a officina onde tiver sido feita a impressão.

Paragrapho unico. Para o effeito da responsabilidade criminal estabelecida no presente artigo, sempre que se tratar de imprensa periodica, o director ou redactor principal será considerado autor de todos os escriptos não assignados e tambem dos assignados por quem não esteja nas condições constantes do n. 1; o gerente será considerado editor; e o proprietario do jornal equiparado ao dono da officina, si na realidade o não fôr.

**Art. 11.** A parte offendida poderá provar, perante o juiz competente, por documentos ou testemunhas, que o autor ou editor do artigo não tem idoneidade ou meios de responder pecuniariamente, afim de poder exercer sua acção contra os responsaveis successivos.

**§ 1º** Esta prova será feita em processo summarissimo, com intimação do autor do artigo ou do editor para, em uma só audiencia, ser o facto provado e contestado.

**§ 2º** Em acto successivo, o juiz decidirá si o autor ou editor tem os requisitos legaes para responder, não cabendo recurso algum dessa decisão.

**§ 3º** Declarado inidoneo o autor ou editor, á parte offendida fica salvo o seu direito contra os responsaveis successivos.

**Art. 12.** Quando a officina graphica ou orgão da imprensa for propriedade de alguma sociedade, esta será representada por seu gerente, salvo havendo prova de caber a outrem, em condições de responder nos termos desta lei, a responsabilidade que se Ihe attribue.

**Art. 13.** Todo diario ou periodico é obrigado a estampar no seu cabeçalho os nomes do director ou redactor principal e do gerente, que deverão estar no gozo de seus direitos civis, e ter residencia no logar onde for feita a publicação, bem assim indicar a séde da administração e do estabelecimento graphico do mesmo jornal ou periodico, sob pena de apprehensão immediata dos exemplares pelas autoridades policiaes.

**Art. 14.** Os artigos publicados nas secções ineditoriaes de qualquer jornal ou periodico deverão conter a assignatura dos respectivos autores e, logo após, as indicações de sua residencia e profissão, e havendo accusações ou injurias, embora vagas e sem declinar nomes, tal assignatura será reconhecida por tabellião do logar, onde o dito jornal ou pariodico fôr impresso e os dezeres dessa formalidade serão reproduzidos no final da publicação, sob pna de multa de 1:000$, sem prejuizo do disposto no art. 10, paragrapho unico.

**Art. 15.** Sempre que um dos responsaveis enumerados no art. 10 gosar immunidades ou de fôro especial, a parte offendida poderá promover acção contra o responsavel ou responsaveis que se lhe seguirem na ordem da responsabilidade successiva determinada no referido artigo.

**Art. 16.** Os gerentes de um jornal ou de qualquer publicação periodica são obrigados a inserir, dentro de tres dias, contados do recebimento a resposta de toda a pessoa natural ou juridica que fôr attingida em publicação do mesmo jornal ou periodico por offensas directas ou referencias de facto inveridico ou erroneo, que possa affectar a sua reputação e boa fama.

**§ 1º** O direito de resposta poderá ser exercido pela propria pessoa assim mencionada, por seu representante legal ou por seus herdeiros, e quem o exercer será o unico juiz do conteúdo, fórma e utilidade da resposta.

**§ 2º** A inserção da resposta será feita gratuita e integralmente em edição correspondente, no mesmo logar e com os mesmos caracteres da publicação que a tiver provocado, e não excederá á extensão desta. Si exceder, a parte excedente será paga pelos preços ordinarios.

**§ 3º** A inserção só poderá ser recusada:

*a)*

quando não tiver relação alguma com os factos referidos na alludida publicação;

*b)*

quando contiver expressões que importem abuso de liberdade de imprensa;

*c)*

quando affectar direitos de terceiros de modo a dar a estes igual direito de resposta.

**§ 4º** Si os gerentes deixarem de inserir a resposta, quando lhes for entregue directamente pelo interessado ou remettida por via postal, poderá este requerer ao juiz competente para processar os crimes referidos no art. 1º, que mande notificar os mesmos gerentes para fazerem a inserção no prazo e sob a pena de multa constante do § 5º do presente artigo. O requerimento será instruido com um exemplar do jornal a que se referir, e com o texto da resposta, em duplicata, para que fique um exemplar archivado em cartorio. A decisão será proferida no prazo de vinte e quatro horas, e della não haverá recurso.

**§ 5º** Sendo a decisão contraria ao gerente do jornal ou periodico, impor-se-lhe-á a multa de 200$ a 2:000$, ficando sujeito a pagar o triplo dessa multa o requerente que tiver instruido sua petição com uma resposta em termos diversos da recusada.

**§ 6º** Si a resposta sahir com alteração que lhe deturpe o sentido, os gerentes serão obrigados a inseril-a de novo, escoimada desse erro; e, si na reproducção o mesmo ou outro apparecer, será considerado proposital e punido com a multa de 200$ a 2:000$, por dia, e o dobro na reincidencia, até inserção exacta do escripto.

**§ 7º** Os gerentes terão o direito de haver do autor do escripto que provocar a resposta todas as despezas com a publicação desta.

**§ 8º** O autor da resposta ou rectificação recusada tem o direito de repetil-a, modificando-a.

**Art. 17.** O exercicio do direito de resposta não inhibirá o offendido ou seu representante de promover a punição dos responsaveis pelas injurias ou calumnias de que fôr victima.

**Art. 18.** Quando a multa recahir sobre algum dos gerentes, socio solidario, ou membro da directoria da empreza, responderão pela importancia da mesma os bens do condemnado, assim como os do jornal e estabelecimento graphico.

Paragrapho unico. A importancia da multa imposta pela condemnação gosará de privilegio especial sobre os ditos bens, ainda no caso de fallencia, derogado para este fim o art. 24, n. 4, da lei n. 2.024, de 17 de dezembro de 1908.

**Art. 19.** As multas pertencerão ao offendido, si este fôr particular, ou á União, Estado ou Municipio, si fôr funccionario em razão do officio, ou corporação que exerça autoridade publica, modificada, assim a norma adoptada pelo artigo 1.547 e seu paragrapho unico do Codigo Civil.

Paragrapho unico. A importancia das multas arrecadadas pela União, pelos Estados ou Municipios constituirá um fundo destinado a fins de assistencia publica, conforme regulamento que, para esse effeito, fôr decretado pelo respectivo Poder Executivo.

DA MATRICULA

**Art. 20.** A matricula das officinas impressoras e dos jornaes e outros periodicos, a que se refere o art. 383 do Codigo Penal, é obrigatoria e será feita em cartorio do Registro de Titulos e Documentos do Districto Federal, do Territorio do Acre e dos Estados; e, em sua falta, nas notas de qualquer tabellião local.

**§ 1º.** O registro será feito em virtude de despacho proferido pela autoridade judiciaria a que estiver subordinado o serventuario que o deva fazer.

**§ 2º** A matricula conterá as declarações seguintes:

1º, nome, residencia, nacionalidade e folha corrida do dono da officina, séde da respectiva administração, o logar, rua e casa onde é estabelecida;  
  
2º, nome, residencia, naturalidade e folha corrida do gerente, e, tratando-se de jornal ou outro escripto periodico, tambem o nome, a residencia, a nacionaIidade e folha corrida do director ou redactor principal, sendo que sempre que se tratar de sociedade deve ficar archivado o respectivo contracto. As alterações supervenientes serão immediatamente averbadas.

**§ 3º** A falta da matricula ou das declarações exigidas neste artigo e a das alterações supervenientes, bem como as falsas declarações, serão punidas com a multa de 500$ a 10:000$, applicavel pela autoridade judiciaria, mediante o processo estabelecido nesta lei e promovido por qualquer interessado ou pelo Ministerio Publico.

**§ 4º** A respectiva sentença determinará o prazo de cinco dias para a matricula ou rectificação das declarações.

**§ 5º** De cada vez que não fôr cumprida essa determinação, o infractor responderá a novo processo, no qual lhe será imposta nova multa pecuniaria, podendo o juiz aggraval-a até 50 %.

DA ACÇÃO E PRESCRIPÇÃO

**Art. 21.** Cabe acção penal mediante queixa do offendido ou de quem tenha qualidade legal para o representar, quando a offensa fôr contra particulares.

**Art. 22.** Cabe acção penal por denuncia do Ministerio Publico, quando a offensa fôr contra corporação que exerça autoridade publica, contra qualquer agente ou depositario desta em razão de suas funcções, contra chefe de estados estrangeiros, ou seus representantes diplomaticos, e ainda no caso do art. 3º; dependendo a acção penal, nesses ultimos casos, de requisição feita, por parte do respectivo Governo, ou pelos representantes diplomaticos offendidos; e mediante officio do Ministerio da Justiça, quando se tratar de offensas ao Presidente da Republica.

Paragrapho unico. Si o promotor publico retardar a denuncia por mais de dez dias após a representação do offendido, ou si recusar a apresental-a, incorrerá na multa de 500$, imposta pelo chefe do Ministerio Publico, e descontada na folha dos seus vencimentos, além da responsabilidade criminal que lhe caiba. Neste caso, poderá o offendido reclamar do chefe do Ministerio Publico a designação de outro promotor, para promover o processo; mantidos os principios dos arts. 407 e 408 do Codigo Penal.

**Art. 23.** Nos crimes de injuria e calumnia, a acção penal e a condemnação prescrevem em dous annos. Paragrapho unico. A demora dos autos além dos prazos legaes e o excesso de prazos, causados pelo réo, serão descontados dos prazos da prescripção.

DO PROCESSO

**Art. 24.** No Districto Federal e no Territorio do Acre observar-se-á nos crimes, de que trata esta lei, o processo seguinte:

**§ 1º** A queixa será offerecida pelo offendido ou seus herdeiros, constantes do artigo 324 do Codigo Penal, pessoalmente, ou por procurador regularmente constituido, sem dependencia de alvará.

**§ 2º** O réo, depois de qualificado, poderá fazer-se representar por procurador bastante, dispensado então o comparecimento pessoal.

**§ 3º** Offerecida queixa ou denuncia instruida obrigatoriamente com um exemplar do impresso offensivo, e, facultativamente, com outros documentos, o juiz mandará autual-a e fazer a citação pessoal do réo abrangendo todos os termos da acção, sendo por edital, com o prazo dez dias, si o citando não fôr encontrado no fôro da acção, para comparecer á primeira audiencia, na qual será qualificado e lhe será assignado o prazo improrogavel de quatro dias para offerecer defesa escripta, contendo todas as prejudiciaes e a exceptio veritatis, sob pena de revelia.

**§ 4º** Si o réo não comparecer á primeira audiencia, o juiz nomear-lhe-á curador á lide, até que compareça e seja qualificado, e o mesmo fará si elle fôr menor ou interdicto.

**§ 5º.** Findo o prazo para a defesa e, seja ou não esta offerecida, na audiencia immediata serão inquiridas as testemunhas que o autor e o réo facultativamente apresentarem e cujo numero não excederá de cinco para cada parte, sendo para esse effeito dispensada citação, salvo quando fôr requerida pela parte que tiver indicado as testemunhas, mas sem prejuizo do prazo do paragrapho seguinte.

**§ 6º** Os depoimentos serão reduzidos a escripto e, si fôr necessario, proseguirão nos dias immediatos, até o maximo improrogavel de oito dias.

**§ 7º** Terminadas as inquirições, terão o autor e o réo, de cada vez, o prazo de tres para examinar os autos em cartorio, e offerecer razões finaes, com ou sem documentos. Ao autor serão dadas mais vinte e quatro horas, improrogaveis, para dizer acerca dos documentos que o réo haja juntado ás suas razões, mas não lhe será permittido exhibir novos documentos.

**§ 8º** Findos os prazos do paragrapho anterior, que não dependerão de assignação e lançamento em audiencia, serão os autos immediatamente conclusos ao juiz, para proferir a sentença, dentro de dez dias.

**§ 9º** Si, antes de proferir a sua sentença, o juiz verificar, ou a parte demonstrar, preterição de formalidades prejudiciaes ao processo, o julgamento será convertido em diligencia, para serem sanadas as nullidades no prazo maximo de dez dias.

**§ 10.** Da sentença caberá appellação, com effeito suspensivo, interposta no prazo de cinco dias, contados da intimação as partes, ou seus procuradores, ou curadores; e, não sendo estes encontrados, do prégão em audiencia.

**§ 11.** Depois de arrazoada a appellação em cartorio, no prazo de cinco dias improrogaveis para cada parte, os autos serão preparados e remettidos á instancia superior, dentro de tres dias, sob pena de deserção, no caso de falta de preparo pelo interessado.

**§ 12.** Na instancia superior a appellação será preparada dentro de dez dias sob pena de deserção, e ficará em mesa por espaço de uma sessão. Na sessão immediata será sorteado o relator, e, na que a esta se seguir, será julgada a appellação, depois de ouvido verbalmente o procurador geral. O accórdão será publicado até a segunda sessão celebrada após a do julgamento e assim terá passado elle em julgado.

**§ 13.** Os prazos constantes do presente artigo não podem ser excedidos, sob pena de pagar a multa de 200$ em cada dia de excesso, quem tiver a culpa do mesmo.

**Art. 25.** A importancia das multas por condemnação definitiva, inclusive as custas, será exequivel no juizo competente, mediante certidão da sentença ou accórdão e da conta das custas, com a qual o autor requererá a citação do executado para pagar em vinte e quatro horas que correrão em cartorio, sob pena de penhora, seguindo-se o processo das acções executivas.

Paragrapho unico. A' penhora o executado apenas poderá oppôr embargos: a) de pagamento; b) de perdão do offendido, si fôr particular; c) de prescripção. Os dous primeiros só poderão ser interpostos com provas literaes incontinenti.

**Art. 26.** Será dada sem demora certidão requerida ás repartições publicas, pelo querellado, para fundamentar a arguição por cuja causa seja chamado a juizo, ou pelo offendido, para provar a falsidade dessa mesma arguição, salvo caso, justificado no despacho de recusa, de tal certidão acarretar damno ao interesse publico.

Paragrapho unico. Recusada a certidão, será suspenso o andamento do processo até que a mesma seja apresentada. Si, porém, o réo de algum modo e por qualquer meio fizer renovar a arguição do mesmo facto que deu causa ao processo, assim suspenso, proseguirá o mesmo independentemente da certidão.

**Art. 27.** Quando fôr intentado processo com manifesta má fé, e o autor decahir por não ter fundamento o seu pedido, pagará o mesmo autor ao réo, além das custas a que tenha sido condemnado, a indemnização do damno causado.

**Art. 28.** A sentença condemnatoria proferida em processo por crime de calumnia ou injuria será publicada gratuitamente na mesma secção do jornal ou periodico onde tiver apparecido o artigo causador da acção criminal, e com os mesmos caracteres graphicos desse artigo; devendo fazer-se a publicação no primeiro ou no segundo numero, de edição correspondente, que se seguir ao conhecimento da sentença, sob pena de multa de 100$ por numero que deixar de fazer a referida publicação.

**Art. 29.** No caso de sentença absolutoria, os autores, querellantes e denunciantes, são obrigados, solidariamente, a arbitrio dos processados, a publicar em um ou dous jornaes ou periodicos, por estes designados, as sentenças respectivas, devendo, na falta de cumprimento dessa obrigação, ser observadas as mesmas regras e penalidades instituidas para os casos da condemnação pelo delicto, em si. Si, para realizar-se essa publicação, fôr necessario recurso judiciario, as publicações, mandadas fazer, correrão por conta dos referidos autores, querellantes e denunciantes, cabendo no caso cobrança executiva.

Esse executivo será processado na mesma ordem e fórma estabelecidas por esta lei, para os casos de execução de sentença condemnatoria.

**Art. 30.** A prisão a que tenham de ser recolhidos os processados por crimes quando commettidos pela imprensa, será sempre distincta da existente para os réos de delictos communs.

DISPOSIÇÕES GERAES

**Art. 31.** Continuam em vigor as disposições do § 2º do art. 23, do art. 59 e paragrapho unico, e as demais disposições do Codigo Penal, que não forem contrarias á presente lei.

**Art. 32.** Tratando-se de abusos da liberdade de pensamento pela imprensa, compete á justiça federal o respectivo julgamento nos casos do art. 126 do Codigo PenaI; ns. 1, 2 e 3 da lei n. 4.269, de 1921; arts. 2º, 3º,e 4º da presente lei; e quando o offendido fôr funccionario federal, em acto, ou por motivo do exercicio de suas funcções.

Paragrapho unico. Nos casos do presente artigo officiará o procurador criminal ou o seccional em logar do promotor publico, observando-se o processo estabelecido nesta lei.

**Art. 33.** Quando duas ou mais qualidades que determinam differença na pena se reunirem na mesma pessoa, considerar-se-á esta investida, quanto aos crimes de que trata esta lei, da qualidade que acarretar maior pena.

**Art. 34.** Fica dispensada, em relação a todo e qualquer impresso, periodico ou não periodico, a prova de sua distribuição por mais de 15 pessoas.

**Art. 35.** A presente lei entrará em vigor desde que seja publicada.

DISPOSIÇÃO TRANSITORIA

**Art. 36.** As actuaes officinas impressoras e as dos jornaes e outros periodicos terão o prazo de noventa dias para effectuar a matricula de que trata o art. 20 da presente lei, a contar da data de sua publicação.

**Art. 37.** Revogam-se as disposições em contrario.

Rio de Janeiro, 31 de outubro de 1923, 102º da Independencia e 35º da Republica.

ARTHUR DA SILVA BERNARDES  
João Luiz Alves
