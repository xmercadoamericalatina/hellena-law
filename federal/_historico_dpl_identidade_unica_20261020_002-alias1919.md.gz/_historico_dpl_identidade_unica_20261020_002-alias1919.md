---
titulo: "Decreto nº 4.182, de 13.11.1919"
tipo: "Decreto do Poder Legislativo"
numero: "4182"
data: 1919-11-13
ementa: "Autoriza o Governo a fazer uma emissão de papel-moeda."
revogada: true
versao_texto: "texto histórico da fonte oficial"
fonte: "https://www.planalto.gov.br/ccivil_03/decreto/historicos/dpl/DPL4182-1920.htm"
fonte_indice: "https://www.planalto.gov.br/ccivil_03/decreto/historicos/dpl/_dpl-ano.htm"
baixado_em: 2026-10-15
urn: "urn:lex:br:federal:decreto.legislativo:1919-11-13;4182"
---

# Decreto nº 4.182, de 13.11.1919

**Presidência da República Casa Civil Subchefia para Assuntos Jurídicos**

**DECRETO Nº 4.182, DE 13 DE NOVEMBRO DE 1920.**

Autoriza o Governo a fazer uma emissão de papel-moeda

**O Presidente da Republica dos Estados Unidos do Brasil:**

Faço saber que o Congresso Nacional decretou e eu sancciono a resolução seguinte:

**Art. 1º** Ao fundo de garantia, instituido pelo art. 2º da lei nº 581, de 20 de julho de 1889, além do ouro amoedado e em barra que o Thesouro possue e fôr adquirindo, serão incorporados:

a) a importancia que se apurar na liquidação dos convenios internacionaes celebrados e que o Governo celebrar com o objecto de compra e venda ou permuta de mercadorias;

b) a importancia dos juros dos titulos da divida externa nacional que o Governo possue e fôr adquirindo, até que seja consummado o respectivo resgate, nos termos dos contractos vigentes.

**§ 1º** Do saldo que annualmente se verificar na arrecadação dos impostos em ouro, pagas as despezas nessa especie e deduzida a quota dada em garantia de operações de credito (art. 5º), metade será applicada ao pagamento de despezas em papel (art. 2º, nº III, da lei nº 3.979, de 31 de dezembro de 1919), e a outra metade será destinada, em partes iguaes, ao fundo de garantia e á incineração do papel-moeda. (Vide Lei nº 4.230, de 1920)

**§ 2º** Toda e qualquer renda ouro extra-orçamentaria que fôr arrecadada será incorporada ao fundo de garantia.

**§ 3º** Desde que o papel-moeda circulante importe em um milhão e quinhentos mil contos de réis, a quota que é destinada á sua incineração será applicada, como reforço, ao fundo de garantia.

**§ 4º** O ouro amoedado ou em barra a que se refere o art. 1º não poderá ser retirado do fundo de garantia, sob pena de responsabilidade do Presidente da Republica e do Ministro da Fazenda que o contrario determinarem, e sob pena de demissão e processo criminal do funccionario ou funccionarios que o executarem.

**Art. 2º** Poderá o Governo applicar á cunhagem de moedas de quinhentos, mil e dous mil réis a prata que possuir e fôr adqurindo; este serviço será feito na Casa da Moeda.

**§ 1º** A despeza correspondente ao custo da prata será escriptada sob o titulo «Conversão de especie».

**§ 2º** A moeda subsidiaria que fôr cunhada só será posta em circulação depois que tiver sido incinerada igual quantia em papel-moeda.

**Art. 3º** Para acudir ás necessidades urgentes do commercio e da producção, por motivo de crise excepecional, poderá o Governo emittir, nos termos da lei nº 3.546, de 2 de outubro de 1918, e empregar até a quantia de 50.000 contos de réis, em emprestimos aos Estados, por intermedio do Banco do Brasil ou mediante redescontos por carteira especial que fôr estabelecida ou por fórma que julgar conveniente.

**§ 1º** Não excederão de um anno os prazos desses emprestimos, nem de 8% os respectivos juros e serão garantidos, na fórma usual, com apolices da divida publica federal, bilhetes do Thesouro Nacional e outros meios que se reputem sufficientes e seguros. A importancia dos juros, convertida em especie, reforçará o fundo de garantia e a do capital será incinerada á medida que forem solvidos os emprestimos.

**§ 2º** Si o fundo de garantia não bastar para a emissão, poderá o Governo reforçal-o com titulos-ouro da divida externa nacional, até que seja consummado o respectivo resgate nos termos dos contractos vigentes, e com outros titulos-ouro que Ihe forem dados em garantia ou pagamento de convenios internacionaes, na relação de 1 para 1 e com o abatimento não menor de 10 % do respectivo valor nominal.

**Art. 4º** Fica o Governo autorizado a applicar tambem o valor total ou parcial das operações de credito que realizar, em virtude da autorização que já se contém na lei nº 3.979, de 31 de dezembro de 1919, art. 58:

a) em beneficio da producção nacional, sob a fórma que entender mais efficaz; e

b) na constituição em Londres e Nova York, de um fundo especiaI, afim de serem deIle utilizados até 50.000 contos na compra e venda de cambiaes, conforme instrucções que expedir, para attender ás necessidades do commercio legitimo de cambio e conter as bruscas oscillações deste.

**Art. 5º** O Governo instituirá a fiscalização dos bancos e casas bancarias, para o fim de prevenir e cohibir o jogo sobre o cambio, assegurando apenas as operações legitimas, observado o seguinte: (Revogado pela Lei nº 14.286, de 2021) (Vigência)

1º, no contracto de compra e venda das cambiaes deverão sempre ficar declarados os nomes do comprador e do vendedor; (Revogado pela Lei nº 14.286, de 2021) (Vigência)

2º, são prohibidas as liquidações por differença das operações sobre letras de cambio e moeda metallica; (Revogado pela Lei nº 14.286, de 2021) (Vigência)

3º, os bancos e instituições que operem com cambio deverão realizar, no Thesouro Nacional, um deposito que será fixado pelo Governo, tendo em vista a importancia das operações. (Revogado pela Lei nº 14.286, de 2021) (Vigência)

**§ 1º** Poderá o Ministro da Fazenda, quando a conveniencia o indicar: (Revogado pela Lei nº 14.286, de 2021) (Vigência)

a) exigir as provas de que as operações de compra e venda de cambiaes são reaes e legitimas, prohibindo-as em caso contrario: (Revogado pela Lei nº 14.286, de 2021) (Vigência)

b) impôr multas correspondentes, no maximo, ao dobro da transacção, e no minimo, de 5:000$, ás pessoas ou ás instituições que infringirem os preceitos deste artigo e as instrucções do Ministro da Fazenda, tendentes á boa execução da presente lei; (Revogado pela Lei nº 14.286, de 2021) (Vigência)

c) as concessões para funccionamento de novos bancos ou casas bancarias, bem como as renovações de concessões, já existentes, dependerão da obrigação de contribuir com uma quota de fiscalização a ser fixada pelo Governo; (Revogado pela Lei nº 14.286, de 2021) (Vigência)

d) estabelecer outras condições e cautelas que forem necessarias para regularizar as operações cambiaes; (Revogado pela Lei nº 14.286, de 2021) (Vigência)

e) fixar uma quota de fiscalização bancaria, de cujo pagamento dependerão o funccionamento de novos bancos e casas bancarias e a renovação de concessões já existentes. (Revogado pela Lei nº 14.286, de 2021) (Vigência)

**§ 2º** Fica autorizado a reorganizar os serviços a cargo da Camara Syndical de Corretores por fórma a melhor assegurar a efficiencia do que dispõe este artigo. (Revogado pela Lei nº 14.286, de 2021) (Vigência)

**§ 3º** Fica o Governo autorizado a expedir os regulamentos necessarios para a execução deste artigo, abrindo os necessarios creditos, e bem assim a consolidar, harmonizando-as quanto possivel, as disposições vigentes sobre sociedades anonymas e bancos.(Revogado pela Lei nº 14.286, de 2021) (Vigência)

**Art. 6º** E' o Governo autorizado, a bem da regularidade das operações a termo, rever e modificar, de accôrdo com os Estados, no que lhes disser respeito, os regulamentos em vigor sobre Bolsas de Mercadorias e Caixas de Liquidação.

**Art. 7º** São supprimidas as actuaes restricções ao commercio e á exportação dos generos aiimenticios de primeira necessidade, ficando entretanto o Governo autorizado, em caso de carencia de qualquer desses generos, a intervir nos mercados para formação dos stocks que forem indispensaveis ao abastecimento interno do paiz, abrindo para isso os necessarios creditos.

**Art. 8º** Prestará o Governo ao Congresso Nacional completa informação do uso que fizer da autorização da presente lei.

**Art. 9º** Fica instituida no Banco do Brasil, sob a superintendencia do presidente desse instituto e a cargo de um director de nomeação do Presidente da Republica, uma Carteira de Emissão e Redesconto, com caixa e contabilidade proprias, emquanto não fôr creado um banco especial para esses fins. O limite de operações dessa carteira será de cem mil contos de réis, e não poderá ser excedido sinão, em caso excepcional, por acto do Presidente da Republica, ficando o Banco sujeito, pela emissão que exceder áquelle limite, á taxa que o Governo determinar. (Vide Decreto-lei nº 14.635, de 21.01.1921) (Vide Decreto-lei nº 19.525, de 24.12.1930)

**§ 1º** Só serão admittidos a redesconto effeitos do commercio, letras de cambio e saques emittidos em moeda nacional, á ordem, de valor não inferior a 5:000$, devidamente sellados e garantidos, pelo menos, por duas firmas commerciaes ou bancarias, plenamente idoneas, e mais o Banco que fôr portador, cujos fundos de reserva tenham com o capital realizado uma relação sufficiente, a juizo do Governo, para assegurar as operações. O prazo dos titulos redescontados não excederá de quatro mezes e a taxa de redesconto de 6 % ao anno. Só serão admittidos a redesconto os papeis emittidos para fins agricolas e industriaes, ficando excluido o papel de especulações mercantis ou que proceda de operações sobre bens de raiz. (Vide Lei nº 4.230, de 1920)

**§ 2º** Contra o valor integral dos titulos redescontados, o Banco do Brasil entregará bilhetes que terão pleno poder liberatorio e cujo montante será estrictamente limitado ao total das operações.

**§ 3º** Os bilhetes que poderão ser identicos aos do Thesouro Nacional, com a inscripção do numero, data da presente lei e carimbo do Banco, poderão ser fornecidos pela Caixa de Amortização, pelo custo, e exclusivamente destinados a redescontos; a respectiva importancia será retirada da circulação por occasião do resgate dos titulos, no dia immediato ao do pagamento improrogavel.

**§ 4º** A importancia dos juros, nas operações de redescontos, será escripturada em conta especial e será destinada: (Revogado pela Lei nº 4.230, de 1920)

30 % ao Banco do Brasil, 20 % ao Thesouro Nacional, (Revogado pela Lei nº 4.230, de 1920)

30 % A formação do fundo de reserva da carteira e 20 %, (Revogado pela Lei nº 4.230, de 1920)

convertidos em ouro, ao fundo de garantia do papel-moeda. (Revogado pela Lei nº 4.230, de 1920)

**§ 5º** A Carteira de Emissão e Redesconto poderá operar dentro das condições acima estabelecidas, com firmas commerciaes e Bancos dos Estados.

**§ 6º** O presidente do Banco do Brasil, o director da Carteira e o thesoureiro serão responsaveis, pessoal e criminalmente, pelas infracções, por excesso ou negligencia, dos dispositivos concernentes ás operações de redesconto e emissão dos respectivos bilhetes.

**§ 7º** O Governo ajustará com o Banco do Brasil as condições para o regular movimento da Carteira, correndo por conta deste instituto todas as despezas.

**§ 8º** Fica creado um conselho de administração composto do director da Carteira, de um dos directores do Banco e de um membro do conselho fiscal deste, designados annualmente pelo overno, para exame e decisão das operações, regular a distribuição pelos bancos da Capital Federal e dos Estados do *quantum* do redesconto, que poderão realizar, assistir á incineração dos bilhetes resgatados e bem assim encaminhar todo o serviço da Carteira, tudo, em caso de duvida ou impugnação, com a audiencia do presidente do Banco ou recurso para o mesmo, ficando assim entendido que ao representante do Governo cabe sempre o direito de *véto*, nas operações de redesconto. Sempre que julgar conveniente ao interesse geral, poderá o Presidente da Republica, ouvindo o conselho de administração, restringir o serviço da Carteira na Capital Federal, ou nos Estados, sem que possa o Banco do Brasil obstar a medida ou reclamar indemnização de qualquer especie.

**§ 9º** Será expedido regulamento dispondo sobre o funccionamento e fiscalização da Carteira, instituição do registro de bancos e firmas, incineração de bilhetes de retirada destes da circulação e sobre tudo que se referir ao apparelho de que trata este artigo.

**Art. 10.** Revogam-se as disposições em contrario.

Rio de Janeiro, 13 de novembro de 1920, 99º da Independencia e 32º da Republica.

EPITACIO PESSÔA

*Homero Baptista.*

Este texto não substitui o publicado na CLBR, de 1920

\*
